package produtojdbc;
public class ProjetoDAO {}