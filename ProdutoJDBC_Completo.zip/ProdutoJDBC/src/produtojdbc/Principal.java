package produtojdbc;
public class Principal { public static void main(String[] args) {} }