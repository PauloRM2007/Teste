package produtojdbc;
public class FuncionarioDAO {}